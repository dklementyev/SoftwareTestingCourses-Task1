<?php

  $widget_config = array(
    'name' => language::translate('title_statistics', 'Statistics'),
    'file' => 'stats.inc.php',
    'priority' => 1,
  );

?>