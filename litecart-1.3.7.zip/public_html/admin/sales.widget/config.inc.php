<?php

  $widget_config = array(
    'name' => language::translate('title_sales', 'Sales'),
    'file' => 'sales.inc.php',
    'priority' => 0,
  );

?>