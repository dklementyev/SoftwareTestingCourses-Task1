<?php
  $box_store_map = new view();
  echo $box_store_map->stitch('views/box_store_map');
?>