<?php

  $box_search = new view();

  echo $box_search->stitch('views/box_search');

?>