<?php @document::$snippets['column_left'] .= $box_information_links; ?>
<!--snippet:box_page-->