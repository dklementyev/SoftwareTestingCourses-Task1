<aside id="navigation" class="column-left box shadow rounded-corners">
  <div class="header columns">
    <div class="toggle column">
      <label for="toggle-menu"><?php echo functions::draw_fonticon('fa-bars'); ?></label>
    </div>

    <div class="search column">
      <!--snippet:box_search-->
    </div>
  </div>

  <input id="toggle-menu" type="checkbox" style="display: none;" />

  <div class="content">
    <!--snippet:box_category_tree-->
    <!--snippet:box_filter-->
    <!--snippet:box_recently_viewed_products-->
    <!--snippet:box_account-->
  </div>
</aside>