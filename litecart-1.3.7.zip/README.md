![LiteCart®](https://www.litecart.net/images/logotype.png "LiteCart®")

----------------------------------------------------------------------

LiteCart is an e-commerce platform for online merchants developed in PHP, HTML 5, and CSS 3.

LiteCart is a registered trademark, property of founder T. Almroth - [TiM International](http://www.tim-international.net).

# Installation Instructions

  1. Copy the contents of the folder public_html/ to your web directory.

  2. Point your web browser to the subfolder install/:

      E.g. http://www.mysite.com/path/to/install

  Good luck!

### [Home Page](http://www.litecart.net)

### [GitHub](https://github.com/litecart/litecart)

### [Issue Tracker](https://github.com/litecart/litecart/issues)

### [Community Forums](http://www.litecart.net/forums/)

### [Community Wiki](http://wiki.litecart.net/)